// [[Rcpp::depends(RcppEigen)]]
#include <RcppEigen.h>
#include <Rcpp.h>
using namespace Rcpp;
using namespace Eigen;

// [[Rcpp::export]]
Eigen::MatrixXd calcQ(Eigen::MatrixXd n_mtx, Eigen::MatrixXd d_mtx, double error) {
  Eigen::MatrixXd Q;
  Q.setZero(d_mtx.rows(),d_mtx.cols());
  for (int i=0; i<Q.rows(); i++){
    for (int j=0; j<Q.cols(); j++){
      Q(i,j) = pow(error,d_mtx(i,j)) * pow(1-error,n_mtx(i,j)-d_mtx(i,j));
    }
  }
  return Q;
}

