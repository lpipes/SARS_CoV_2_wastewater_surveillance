// [[Rcpp::depends(RcppEigen)]]
#include <RcppEigen.h>
#include <Rcpp.h>
using namespace Rcpp;
using namespace Eigen;

// [[Rcpp::export]]
double logL(Eigen::VectorXd p, Eigen::MatrixXd y) {
  Eigen::MatrixXd w;
  Eigen::VectorXd w_tmp;
  w.setZero(y.rows(),y.cols());
  for (int j=0; j<w.cols(); j++){
    w.col(j) = y.col(j) * p(j);
  }
  w_tmp = w.rowwise().sum();
  w_tmp = w_tmp.array().log();
  return w_tmp.sum();
}

// [[Rcpp::export]]
double neg_logL(Eigen::VectorXd p, Eigen::MatrixXd y){
  return -logL(p,y);
}
