// [[Rcpp::depends(RcppEigen)]]
#include <RcppEigen.h>
#include <Rcpp.h>
using namespace Rcpp;
using namespace Eigen;

// [[Rcpp::export]]
NumericVector EM(Eigen::VectorXd p, Eigen::MatrixXd y) {
  Eigen::MatrixXd w;
  Eigen::VectorXd E_step;
  w.setZero(y.rows(),y.cols());
  for (int j=0; j<w.cols(); j++){
    w.col(j) = y.col(j) * p(j);
  }
  for (int i=0; i<w.rows(); i++){
    w.row(i) = w.row(i) / w.row(i).sum();
  }
  E_step = w.colwise().sum() / w.rows();
  Rcpp::NumericVector xx(wrap(E_step));
  return xx;
}

